
Use Packet Tracer:
1. Place devices symmetrically
2. Configure VLANs
3. Enable routing
4. Test ping between VLANs
