
• Three-tier network architecture
• VLAN segmentation
• OSPF routing
• Firewall protection
• Visualization mirrors real config
