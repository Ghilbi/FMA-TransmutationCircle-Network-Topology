
import { useEffect, useState } from "react";

export default function App() {
  const [devices, setDevices] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    fetch("http://localhost:5000/devices")
      .then(r => r.json())
      .then(setDevices);
  }, []);

  const c = 300;
  const r = 220;

  return (
    <div style={{ display: "flex", fontFamily: "monospace" }}>
      <svg width="600" height="600">
        <circle cx={c} cy={c} r={r} fill="none" stroke="black" strokeWidth="3"/>
        <circle cx={c} cy={c} r={120} fill="none" stroke="black" strokeWidth="2"/>
        {devices.map((d, i) => {
          const a = (i / devices.length) * 2 * Math.PI;
          return (
            <g key={d.id}>
              <line x1={c} y1={c} x2={c + r*Math.cos(a)} y2={c + r*Math.sin(a)} stroke="black"/>
              <circle
                cx={c + r*Math.cos(a)}
                cy={c + r*Math.sin(a)}
                r="22"
                fill="black"
                onClick={() => setSelected(d)}
              />
            </g>
          );
        })}
      </svg>

      <div style={{ marginLeft: 20, width: 400 }}>
        {selected ? (
          <>
            <h3>{selected.name}</h3>
            <p><b>Symbol:</b> {selected.symbol}</p>
            <pre>{selected.config}</pre>
          </>
        ) : <p>Click a symbol</p>}
      </div>
    </div>
  );
}
